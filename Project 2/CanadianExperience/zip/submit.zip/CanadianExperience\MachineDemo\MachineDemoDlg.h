/**
 * \file MachineDemoDlg.h
 * The machine demostration dialog box class
 * \author Charles Owen
 */


#pragma once
#include "afxcmn.h"
#include "afxwin.h"
#include <string>

#include "MachineDemoView.h"

/**
 * The machine demonstration dialog box class
 */
class CMachineDemoDlg : public CDialogEx
{
public:
	CMachineDemoDlg(CWnd* pParent = NULL);	// standard constructor

	/// Dialog box ID
	enum { IDD = IDD_MACHINEDEMO_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;  ///< Icon handle

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
    afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
    afx_msg void OnSize(UINT nType, int cx, int cy);
    afx_msg void OnBnClickedButtonNewMachine();

	void SetFrameNum(int frame);
	void SetMachineNum(int num);

	/**
	 * Set the filename to save the machine image as
	 * @param filename Filename
	*/
	void SetSaveFile(const std::wstring& filename) { mMachineView.SetSaveFile(filename); }

	/**
	 * Set a label to add to the machine
	 * @param label Label string to add to the machine
	*/
	void SetLabel(const std::wstring& label) { mMachineView.SetLabel(label); }

	/**
	 * Set if machine is to die after image is saved 
	 * @param die True shuts down machine after image saved
	*/
	void SetDie(bool die) { mMachineView.SetDie(die); }

private:
    int mFrameNum = 0;			///< Frame number, assumed 30 frames per second
	double mScale = 1.0;		///< Amount to scale

    void UpdateUI();
    CSliderCtrl mTimeSlider;    ///< The time/frame slider
    CStatic mFrame;             ///< Current frame
        
    CMachineDemoView mMachineView;    ///< The machine viewer window
   
    CStatic mMachineNumberView;		///< View were we put the machine number
	CButton mPlayButton;		///< The Play button control
	CButton mStopButton;		///< The Stop button control
	CButton mRwButton;			///< The Rewind button control

public:
	afx_msg void OnBnClickedPlay();
	afx_msg void OnBnClickedStop();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnBnClickedRw();
	afx_msg void OnTRBNThumbPosChangingScaleslider(NMHDR* pNMHDR, LRESULT* pResult);

	/** \cond */

	UINT_PTR mTimer = 0;	///< The ID for the timer that controls playback

	long long mLastTime = 0;    ///< Last time we read the timer
	double mTimeFreq = 0;       ///< Rate the timer updates
	int mInitialMachine = 0;	///< The initial machine to use, 0 means none

	double mTime = 0;			///< Running time

	/// The on-screen controls
	CStatic mControls;

	/// The scale slider
	CSliderCtrl mScaleSlider;

	/** \endcond */
};