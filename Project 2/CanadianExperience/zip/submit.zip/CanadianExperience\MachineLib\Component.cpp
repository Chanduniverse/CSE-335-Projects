/**
 * \file Component.cpp
 *
 * \author Chandan Aralikatti
 */

#include "pch.h"
#include "Component.h"
