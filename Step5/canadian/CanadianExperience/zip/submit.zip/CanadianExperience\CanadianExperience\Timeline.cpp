/**
 * \file Timeline.cpp
 *
 * \author Chandan Aralikatti
 */

#include "pch.h"
#include "Timeline.h"

/**
* Constructor
*/
CTimeline::CTimeline()
{
}