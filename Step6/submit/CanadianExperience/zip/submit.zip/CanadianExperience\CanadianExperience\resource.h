//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CanadianExperience.rc
//
#define IDD_TIMELINEDLG                 9
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_CanadianExperieTYPE         130
#define IDR_VIEWEDIT                    131
#define IDR_VIEWACTORS                  132
#define IDR_VIEWTIMELINE                137
#define IDB_BITMAP1                     316
#define IDB_HAROLD_SMALL                316
#define IDC_NUMFRAMES                   1001
#define IDC_EDIT1                       1002
#define IDC_FRAMERATE                   1002
#define ID_FILE_TEST                    32771
#define ID_EDIT_MOVE                    32772
#define ID_EDIT_ROTATE                  32773
#define ID_EDIT_SETKEYFRAME             32774
#define ID_EDIT_DELETEKEYFRAME          32775
#define ID_BUTTON32779                  32779
#define ID_EDIT_TIMELINEPROPERTIES      32780

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        319
#define _APS_NEXT_COMMAND_VALUE         32781
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
